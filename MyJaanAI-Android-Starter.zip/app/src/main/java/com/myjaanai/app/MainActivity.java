package com.myjaanai.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_SPEECH = 21;
    private static final int REQ_MIC = 22;
    private TextView answer;
    private EditText apiKey;
    private TextToSpeech tts;
    private String lastQuestion = "";

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("bn", "IN"));
        });
        buildUI();
    }

    private void buildUI() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 36, 28, 28);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(0xFFF7F5FF);
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("❤️ My Jaan AI");
        title.setTextSize(30);
        title.setTextColor(0xFF312E81);
        title.setGravity(Gravity.CENTER);
        root.addView(title, match());

        TextView subtitle = new TextView(this);
        subtitle.setText("আপনার বাংলা কণ্ঠস্বর সহকারী");
        subtitle.setTextSize(16);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, 8, 0, 24);
        root.addView(subtitle, match());

        Button mic = new Button(this);
        mic.setText("🎙️ কথা বলুন");
        root.addView(mic, match());
        mic.setOnClickListener(v -> startVoice());

        answer = new TextView(this);
        answer.setText("নমস্কার! কথা বলার বোতামে চাপ দিন।\nAI উত্তর পেতে নিচে API key দিন।");
        answer.setTextSize(18);
        answer.setTextColor(0xFF24213A);
        answer.setPadding(12, 24, 12, 24);
        root.addView(answer, match());

        TextView keyLabel = new TextView(this);
        keyLabel.setText("AI API key (শুধু নিজের ফোনে ব্যবহার করুন; অন্যকে দেখাবেন না)");
        keyLabel.setTextSize(14);
        root.addView(keyLabel, match());

        apiKey = new EditText(this);
        apiKey.setSingleLine(true);
        apiKey.setHint("আপনার Gemini API key");
        apiKey.setInputType(129);
        root.addView(apiKey, match());

        Button send = new Button(this);
        send.setText("AI-কে প্রশ্ন পাঠান");
        root.addView(send, match());
        send.setOnClickListener(v -> {
            if (lastQuestion.trim().isEmpty()) {
                Toast.makeText(this, "আগে কথা বলুন অথবা প্রশ্ন লিখুন", Toast.LENGTH_SHORT).show();
                return;
            }
            String key = apiKey.getText().toString().trim();
            if (key.isEmpty()) {
                answer.setText("AI চালু করতে Gemini API key দরকার। আপাতত আপনার কথা শনাক্ত হয়েছে: " + lastQuestion);
                return;
            }
            answer.setText("AI সংযোগের জন্য নিরাপদ সার্ভার সেটআপ এখনো যোগ করা হয়নি। আপনার প্রশ্ন: " + lastQuestion);
            tts.speak("আপনার কথা আমি শুনেছি। AI সংযোগ সেটআপ করতে হবে।", TextToSpeech.QUEUE_FLUSH, null, "reply");
        });

        EditText typed = new EditText(this);
        typed.setHint("অথবা এখানে প্রশ্ন লিখুন");
        root.addView(typed, match());
        Button useTyped = new Button(this);
        useTyped.setText("লেখা ব্যবহার করুন");
        root.addView(useTyped, match());
        useTyped.setOnClickListener(v -> {
            lastQuestion = typed.getText().toString();
            answer.setText("আপনার প্রশ্ন: " + lastQuestion);
        });
        setContentView(scroll);
    }

    private android.widget.LinearLayout.LayoutParams match() {
        return new android.widget.LinearLayout.LayoutParams(-1, -2);
    }

    private void startVoice() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "এই ফোনে speech recognition পাওয়া যাচ্ছে না। Google app আপডেট করুন।", Toast.LENGTH_LONG).show();
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            return;
        }
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-IN");
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "বাংলায় বলুন");
        try { startActivityForResult(intent, REQ_SPEECH); }
        catch (Exception e) { Toast.makeText(this, "ভয়েস ইনপুট চালু করা গেল না", Toast.LENGTH_SHORT).show(); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_SPEECH && resultCode == RESULT_OK && data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) {
                lastQuestion = results.get(0);
                answer.setText("আপনি বলেছেন: " + lastQuestion + "\nএবার AI সংযোগ দরকার, যাতে বুদ্ধিমান উত্তর দিতে পারে।");
            }
        }
    }

    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
