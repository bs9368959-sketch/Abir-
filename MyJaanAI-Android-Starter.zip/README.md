# MyJaanAI Android starter project

This is a starter Android project for a Bengali voice assistant. It includes Android speech recognition and text-to-speech UI, plus a GitHub Actions workflow to build a debug APK.

## Important
- The current version recognizes Bengali speech and shows the recognized text.
- It does **not yet produce real AI answers**. A secure backend/API integration still needs to be added.
- Do not commit API keys to GitHub or hard-code them in source code.
- GitHub Actions builds this project using `gradle assembleDebug`; if the build fails, review the Actions logs.

## Build with GitHub
Upload all files/folders from this ZIP to the root of your `MyJaanAI` repository (or a new repository), commit them, then open **Actions** and select **Build MyJaanAI APK**. Download the artifact named `MyJaanAI-debug-apk`.
